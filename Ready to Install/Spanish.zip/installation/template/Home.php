<div class="container-fluid" id='login'>	
	<div class="row">
		<div class="col-md-6 offset-md-3 col-lg-4 offset-lg-4">
			<div class="card mx-30" style="opacity: 80%">
				<div class="text-center">
					<i class="fa fa-info-circle fa-5x icon-text"></i>
					<h3 class="my-0">Installation</h3>
					<p class="my-0 mb-5">Hi there! looks like you have not installed MOFY yetplease click on the button bellow to start installation. <i class="fa fa-smile"></i></p>
					<a href="install.php" class="btn btn-primary">Install Now!</a>
				</div>
			</div>
		</div>
	</div>
</div>