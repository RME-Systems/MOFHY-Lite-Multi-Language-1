<?php
	header('location: Home.php');
?>