<div class="container-fluid" id='login'>	
	<div class="row">
		<div class="col-md-6 offset-md-3 col-lg-4 offset-lg-4">
			<div class="card mx-30" style="opacity: 80%">
				<h5 class="text-center my-0">Clientarea</h5><hr>
				<form action="function/Step1.php" method="post">
					<div class="mb-5">
						<label class="form-label">Clientarea Name</label>
						<input type="text" name="name" class="form-control" placeholder="Enter clientarea name here...">
					</div>
					<div class="mb-5">
						<label class="form-label">Clientarea URL</label>
						<input type="text" name="url" class="form-control" placeholder="Enter clientarea url here...">
					</div>
					<div class="mb-10">
						<label class="form-label">Clientarea Email</label>
						<input type="text" name="email" class="form-control" placeholder="Enter clientarea email here...">
					</div>
					<div class="mb-0">
						<input type="submit" name="submit" class="btn btn-primary mb-0" value="Next Step">
					</div>
				</form>
			</div>
		</div>
	</div>
</div>