<div class="container-fluid" id='login'>	
	<div class="row">
		<div class="col-md-6 offset-md-3 col-lg-4 offset-lg-4">
			<div class="card mx-30" style="opacity: 80%">
				<div class="text-center">
					<i class="fa fa-info-circle fa-5x icon-text"></i>
					<h3 class="my-0"><?php echo $text['maintaince_title'];?></h3>
					<p class="mt-0"><?php echo $text['maintaince_text'];?></p>
				</div>
			</div>
		</div>
	</div>
</div>
