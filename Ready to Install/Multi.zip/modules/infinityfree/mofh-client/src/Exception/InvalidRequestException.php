<?php

namespace InfinityFree\MofhClient\Exception;

class InvalidRequestException extends \Exception
{

}