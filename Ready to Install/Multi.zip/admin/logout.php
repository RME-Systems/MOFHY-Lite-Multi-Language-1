<?php
include __DIR__.'/function/Logout.php';
?>