<?php
header('location: function/ResendEmail.php?resend=true');
?>